<!-- Below script for ck editor -->
<!-- <script src="//cdn.ckeditor.com/4.5.9/standard/ckeditor.js"></script> -->
<script src="//cdn.ckeditor.com/4.7.0/full/ckeditor.js"></script>
<script>
	CKEDITOR.replace( 'product_info' );
</script>
<style type="text/css">
	.cke_top, .cke_contents, .cke_bottom {
		border: 1px solid #333;
	}
</style>