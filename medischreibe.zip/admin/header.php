<nav class="cyan darken-1">
                    <div class="nav-wrapper row">
                        <section class="material-design-hamburger navigation-toggle">
                            <a href="javascript:void(0)" data-activates="slide-out" class="button-collapse show-on-large material-design-hamburger__icon">
                                <span class="material-design-hamburger__layer"></span>
                            </a>
                        </section>
                        <div class="header-title col s3 m3">      
                            <span class="chapter-title"><a href = "dashboard.php"/>Sampradaya Ruchulu</span>
                        </div>
                        <form class="left search col s6 hide-on-small-and-down">
                            <a href="javascript: void(0)" class="close-search"><i class="material-icons">close</i></a>
                        </form>                        
                        
                    </div>
                </nav>